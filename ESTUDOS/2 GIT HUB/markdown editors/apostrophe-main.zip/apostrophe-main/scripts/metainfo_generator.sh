#!/bin/bash

appstreamcli news-to-metainfo --limit=3 NEWS data/org.gnome.gitlab.somas.Apostrophe.metainfo.xml.in.in data/org.gnome.gitlab.somas.Apostrophe.metainfo.xml.in   

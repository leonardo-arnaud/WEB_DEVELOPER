
ninja -C builddir apostrophe-pot
ninja -C builddir apostrophe-update-po